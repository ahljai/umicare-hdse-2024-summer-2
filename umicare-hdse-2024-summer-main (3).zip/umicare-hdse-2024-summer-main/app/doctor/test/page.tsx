import { useSession } from 'next-auth/react';

const TestPage = () => {
  const { data: session, status } = useSession();

  if (status === 'loading') {
    return <p>Loading...</p>;
  }

  if (!session) {
    return <p>No session found</p>;
  }

  return (
    <div>
      <h1>Hello, {session.user?.name}</h1>
      <p>Your email is: {session.user?.email}</p>
    </div>
  );
};

export default TestPage;