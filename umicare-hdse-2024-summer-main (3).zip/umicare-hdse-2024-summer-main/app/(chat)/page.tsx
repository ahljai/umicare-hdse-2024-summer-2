import { nanoid } from '@/lib/utils'
import { Chat } from '@/components/chat'
import { AI } from '@/lib/chat/actions'
import { auth } from '@/auth'
import { Session } from '@/lib/types'
import { getMissingKeys } from '@/app/actions'

export const metadata = {
  title: 'Umi-Care'
}

export default async function IndexPage() {
  const id = nanoid()
  const session = (await auth()) as Session
  const missingKeys = await getMissingKeys()

  if (!session) {
    return <div>Please log in to access Umi Care's services.</div>
  }

  if (missingKeys.length > 0) {
    return <div>Missing required configurations: {missingKeys.join(', ')}</div>
  }

  return (
    <AI
      initialAIState={{
        chatId: id,
        messages: [],
        initialPrompt: `You are an AI assistant helping a patient at Umi Care. The patient might ask healthcare-related questions. Please provide accurate, clear, and helpful responses.`
      }}
    >
      <Chat id={id} session={session} missingKeys={missingKeys} />
    </AI>
  )
}
