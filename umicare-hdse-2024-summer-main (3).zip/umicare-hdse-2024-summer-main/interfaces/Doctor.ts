// interfaces/Doctor.ts
export interface Doctor {
    id: string;
    name: string;
    contactNumber: string;
    specialty?: string;
  }
  